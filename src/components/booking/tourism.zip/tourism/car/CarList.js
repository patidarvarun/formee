import React, { Fragment } from "react";
import { components } from "react-select";

class CarListDetail extends React.Component {
  render() {
    return (
      <h2 style={{ display: "block", margin: "0 auto", minHeight: "40vh" }}>
        Car List content Coming Soon!
      </h2>
    );
  }
}
export default CarListDetail;

// import React, { Fragment } from "react";
// import { Link, Redirect, withRouter } from "react-router-dom";
// import { connect } from "react-redux";
// import CarListDetail from "../../../../components/common/carListingDetail/CarListDetail";
// import AppSidebar from "../../common/Sidebar";
// import {
//   Layout,
//   Row,
//   Col,
//   Typography,
//   Card,
//   Form,
//   Select,
//   Breadcrumb,
//   Rate,
// } from "antd";
// import Icon from "../../../../components/customIcons/customIcons";
// import { langs } from "../../../../config/localization";
// import {
//   mostPopularInHandyMan,
//   newInBookings,
//   mostPapularList,
//   getMostViewdData,
//   getBannerById,
//   enableLoading,
//   disableLoading,
// } from "../../../../actions/index";
// import {
//   papularSearch,
//   getClassfiedCategoryListing,
//   classifiedGeneralSearch,
//   getClassfiedCategoryDetail,
//   openLoginModel,
//   getChildCategory,
// } from "../../../../actions";
// import DetailCard from "../../common/Card";
// import history from "../../../../common/History";
// import { CarouselSlider } from "../../../common/CarouselSlider";
// import SubHeader from "../../common/SubHeader";
// import NoContentFound from "../../../common/NoContentFound";
// import "../../../common/bannerCard/bannerCard.less";
// import { TEMPLATE } from "../../../../config/Config";
// // import { converInUpperCase } from "../../common";
// import { DEFAULT_THUMB_IMAGE } from "../../../../config/Config";
// import FlightListCard from "../../../common/flightCard/FlightListCard";
// import NewSidebar from "../../NewSidebar";
// import "../tourism.less";
// import "./car.less";
// const { Option } = Select;
// const { Content } = Layout;
// const { Title, Paragraph, Text } = Typography;
// const customBannerImage = require("../../../../../assets/images/tourism-car-banner.png");
// const topRatedCarImage = require("../../../../../assets/images/toyota-yaris.png");
// const importCompanyLogo = require("../../../../../assets/images/euro-logo.png");

// const topRatedCarRentalData = [
//   {
//     image: topRatedCarImage,
//     name: "Kuala lumpur",
//     offer: "Save 55%",
//     subCategory: "Subcategory",
//     similar: "or similar",
//     price: "120",
//     companyLogo: importCompanyLogo,
//   },
//   {
//     image: topRatedCarImage,
//     name: "Kuala lumpur",
//     offer: "Save 55%",
//     subCategory: "Subcategory",
//     similar: "or similar",
//     price: "120",
//     companyLogo: importCompanyLogo,
//   },
//   {
//     image: topRatedCarImage,
//     name: "Kuala lumpur",
//     offer: "Save 55%",
//     subCategory: "Subcategory",
//     similar: "or similar",
//     price: "120",
//     companyLogo: importCompanyLogo,
//   },
//   {
//     image: topRatedCarImage,
//     name: "Kuala lumpur",
//     offer: "Save 55%",
//     subCategory: "Subcategory",
//     similar: "or similar",
//     price: "120",
//     companyLogo: importCompanyLogo,
//   },
//   {
//     image: topRatedCarImage,
//     name: "Kuala lumpur",
//     offer: "Save 55%",
//     subCategory: "Subcategory",
//     similar: "or similar",
//     price: "120",
//     companyLogo: importCompanyLogo,
//   },
// ];
// class FlightList extends React.Component {
//   formRef = React.createRef();
//   constructor(props) {
//     super(props);
//     this.child = React.createRef();
//     this.state = {
//       key: "tab1",
//       noTitleKey: "app",
//       BookingList: [],
//       subCategory: [],
//       filteredData: [],
//       isFilterPage: false,
//       isSearchResult: false,
//       catName: "",
//       isOpen: false,
//       searchLatLng: "",
//       mostRecentList: [],
//       topRatedList: [],
//       papularViewData: [],
//       searchReqData: {},
//       viewAll: false,
//       mostPapular: [],
//       bottomImages: [],
//       middle1Images: [],
//       middle2Images: [],
//       middle3Images: [],
//       tabKey: 1,
//       most_popular: [],
//       isSidebarOpen: false,
//     };
//   }

//   /**
//    * @method componentWillReceiveProps
//    * @description receive props
//    */
//   componentWillReceiveProps(nextprops, prevProps) {
//     let catIdInitial = this.props.match.params.categoryId;
//     let catIdNext = nextprops.match.params.categoryId;
//     if (catIdInitial !== catIdNext) {
//       this.props.enableLoading();
//       this.getMostRecentData();
//       this.getMostPopularData(catIdNext);
//       this.getBannerData();
//     }
//   }

//   /**
//    * @method componentWillMount
//    * @description called before mounting the component
//    */
//   componentWillMount() {
//     this.props.enableLoading();
//     let cat_id = this.props.match.params.categoryId;
//     this.getMostRecentData();
//     this.getMostPopularData(cat_id);
//     this.getBannerData();
//   }

//   /**
//    * @method getMostPopularData
//    * @description get most papular data
//    */
//   getMostPopularData = (cat_id) => {
//     let requestData = {
//       booking_cat_id: cat_id,
//     };
//     this.props.mostPopularInHandyMan(requestData, (res) => {
//       this.props.disableLoading();
//       if (res.status === 200) {
//         const data =
//           res.data &&
//           res.data.data &&
//           Array.isArray(res.data.data) &&
//           res.data.data.length
//             ? res.data.data
//             : [];
//         this.setState({ imageUrl: res.data.data.imageurl, mostPapular: data });
//       }
//     });
//   };

//   /**
//    * @method getBannerData
//    * @description get banner detail
//    */
//   getBannerData = () => {
//     this.props.getBannerById(4, (res) => {
//       this.props.disableLoading();
//       if (res.status === 200) {
//         const data =
//           res.data.success && Array.isArray(res.data.success.banners)
//             ? res.data.success.banners
//             : "";
//         const banner = data;
//         const top =
//           banner && banner.filter((el) => el.bannerPosition === langs.key.top);
//         const bottom =
//           banner &&
//           banner.filter((el) => el.bannerPosition === langs.key.bottom);
//         const middleOne =
//           banner &&
//           banner.filter((el) => el.bannerPosition === langs.key.middle_one);
//         const middleTwo =
//           banner &&
//           banner.filter((el) => el.bannerPosition === langs.key.middle_two);
//         const middleThree =
//           banner &&
//           banner.filter((el) => el.bannerPosition === langs.key.middle_three);
//         this.setState({
//           topImages: top,
//           bottomImages: bottom,
//           middle1Images: middleOne,
//           middle2Images: middleTwo,
//           middle3Images: middleThree,
//         });
//       }
//     });
//   };

//   /**
//    * @method getMostRecentData
//    * @description get most recent booking data
//    */
//   getMostRecentData = () => {
//     const { isLoggedIn, loggedInDetail } = this.props;
//     let parameter = this.props.match.params;
//     let cat_id = parameter.categoryId;
//     const requestData = {
//       user_id: isLoggedIn ? loggedInDetail.id : "",
//       page: 1,
//       per_page: 12,
//       cat_id,
//     };
//     this.props.newInBookings(requestData, (res) => {
//       this.props.disableLoading();
//       if (res.status === 200) {
//         const data = Array.isArray(res.data.data) ? res.data.data : [];
//         this.setState({ mostRecentList: data });
//       }
//     });
//     this.getTopRatedData();
//     this.getMostPopularList();
//   };

//   /**
//    * @method getTopRatedData
//    * @description get top rated records
//    */
//   getTopRatedData = () => {
//     const { isLoggedIn, loggedInDetail } = this.props;
//     let parameter = this.props.match.params;
//     let cat_id = parameter.categoryId;
//     const requestData = {
//       user_id: isLoggedIn ? loggedInDetail.id : "",
//       page: 1,
//       per_page: 12,
//       cat_id,
//       filter: "top_rated",
//     };
//     this.props.newInBookings(requestData, (res) => {
//       this.props.disableLoading();
//       if (res.status === 200) {
//         const data = Array.isArray(res.data.data) ? res.data.data : [];
//         this.setState({ topRatedList: data });
//       }
//     });
//   };

//   /**
//    * @method getMostPopularList
//    * @description get most popular list
//    */
//   getMostPopularList = () => {
//     const { isLoggedIn, loggedInDetail } = this.props;
//     let parameter = this.props.match.params;
//     let cat_id = parameter.categoryId;
//     const requestData = {
//       user_id: isLoggedIn ? loggedInDetail.id : "",
//       page: 1,
//       per_page: 12,
//       cat_id,
//       filter: "most_popular",
//     };
//     this.props.newInBookings(requestData, (res) => {
//       this.props.disableLoading();
//       if (res.status === 200) {
//         const data = Array.isArray(res.data.data) ? res.data.data : [];
//         this.setState({ most_popular: data });
//       }
//     });
//   };

//   /**
//    * @method onTabChange
//    * @description manage tab change
//    */
//   onTabChange = (key, type) => {
//     this.setState({ [type]: key, tabKey: key });
//   };

//   /**
//    * @method handleSearchCall
//    * @description Call Action for Classified Search
//    */
//   handleSearchCall = () => {
//     this.props.classifiedGeneralSearch(this.state.searchReqData, (res) => {
//       this.setState({ BookingList: res.data });
//     });
//   };

//   /**
//    * @method handleSearchResponce
//    * @description Call Action for Classified Search
//    */
//   handleSearchResponce = (res, resetFlag, reqData) => {
//     let cat_id = this.props.match.params.categoryId;
//     if (resetFlag) {
//       this.setState({ isSearchResult: false });
//       this.getMostRecentData(cat_id);
//     } else {
//       this.setState({
//         BookingList: res,
//         isSearchResult: true,
//         searchReqData: reqData,
//       });
//     }
//   };

//   /**
//    * @method renderMostPapularItem
//    * @description render most popular item
//    */
//   renderMostPapularItem = (mostPapular, imageUrl) => {
//     if (mostPapular && mostPapular.length) {
//       return (
//         <Row gutter={[20, 20]}>
//           {mostPapular &&
//             mostPapular.map((el, i) => {
//               let a = el.description;
//               let discription = document.createElement("div");
//               discription.innerHTML = a;
//               return (
//                 <Col span={8} key={i}>
//                   <div className={"imageCard handyman-mostpopular"}>
//                     <div className="ad-banner">
//                       <img
//                         src={
//                           el.banner_image
//                             ? el.banner_image
//                             : DEFAULT_THUMB_IMAGE
//                         }
//                         onError={(e) => {
//                           e.target.onerror = null;
//                           e.target.src = DEFAULT_THUMB_IMAGE;
//                         }}
//                         alt=""
//                       />
//                     </div>
//                     <div className={"imageCardContent"}>
//                       <Title level={2} className="mb-5">
//                         {discription.innerText}
//                       </Title>
//                       <Paragraph
//                         className="fs-14 mb-0"
//                         style={{ lineHeight: "22px" }}
//                       >
//                         {el.name}
//                         <Icon icon="arrow-right" size="12" className="ml-40" />
//                         <br />
//                         {`{
//                           el.parent_category_classifieds_count
//                             ? el.parent_category_classifieds_count
//                             : 0
//                         }  Ads`}
//                       </Paragraph>
//                     </div>
//                   </div>
//                 </Col>
//               );
//             })}
//         </Row>
//       );
//     }
//   };

//   /**
//    * @method renderCard
//    * @description render card details
//    */
//   renderCard = (categoryData) => {
//     let parameter = this.props.match.params;
//     let cat_id = parameter.categoryId;
//     if (Array.isArray(categoryData) && categoryData.length) {
//       let list = this.state.isSearchResult
//         ? categoryData
//         : categoryData.slice(0, 12);
//       return (
//         <Fragment>
//           <Row gutter={[38, 38]}>
//             {list.map((data, i) => {
//               return (
//                 <DetailCard
//                   data={data}
//                   key={i}
//                   handyman={"handyman"}
//                   callNext={() => {
//                     if (this.state.isSearchResult) {
//                       this.handleSearchCall();
//                     } else {
//                       this.getMostRecentData(cat_id);
//                     }
//                   }}
//                 />
//               );
//             })}
//           </Row>
//         </Fragment>
//       );
//     } else {
//       return <NoContentFound />;
//     }
//   };

//   /**
//    * @method render
//    * @description render component
//    */
//   render() {
//     const { isSidebarOpen, redirectTo, topImages } = this.state;
//     const parameter = this.props.match.params;
//     let cat_id = parameter.categoryId;
//     return (
//       <Layout className="common-sub-category-landing booking-sub-category-landing">
//         <Layout className="yellow-theme common-left-right-padd">
//           <NewSidebar
//             history={history}
//             activeCategoryId={cat_id}
//             categoryName={TEMPLATE.HANDYMAN}
//             isSubcategoryPage={true}
//             showAll={true}
//             toggleSideBar={() =>
//               this.setState({ isSidebarOpen: !isSidebarOpen })
//             }
//           />
//           <Layout className="right-parent-block">
//             <div className="inner-banner custom-inner-banner">
//               <SubHeader categoryName={TEMPLATE.HANDYMAN} showAll={true} />
//               <CarouselSlider bannerItem={topImages} pathName="/" />
//               <div className="tourism-main-banner">
//                 {/* <img
//                   src={require("../../../assets/images/hand-img.png")}
//                   alt=""
//                 /> */}
//                 {/* <div className="tourism-main-banner-content">
//                   <Title level={2} className="heading">
//                     Plan your dream trip
//                   </Title>
//                   <Text className="fs-17 sub-heading">
//                     Get the best prices on 2,000,000+ properties, worldwide
//                   </Text>
//                   <div className="banner-btn-box">
//                     <div className="fm-tab-names">
//                       <img
//                         src={require("../../../../assets/images/flight-icon.svg")}
//                       />
//                       <span>Flights</span>
//                     </div>
//                     <div className="fm-tab-names">
//                       <img
//                         src={require("../../../../assets/images/hotel-icon.svg")}
//                       />
//                       <span>Hotels</span>
//                     </div>
//                     <div className="fm-tab-names">
//                       <img
//                         src={require("../../../../assets/images/car-icon.svg")}
//                       />
//                       <span>Car</span>
//                     </div>
//                     <div className="fm-tab-names">
//                       <img
//                         src={require("../../../../assets/images/tours-attractions-icon.svg")}
//                       />
//                       <span>Tours & Attractions</span>
//                     </div>
//                   </div>
//                 </div> */}
//               </div>
//             </div>
//             <Content className="site-layout">
//               <div className="wrap-inner full-width-wrap-inner bg-gray-linear">
//                 <Row className="mb-20" align="middle">
//                   <Col md={16}>
//                     <Breadcrumb
//                       separator="|"
//                       className="ant-breadcrumb-pad ant-breadcrumb-pad-none"
//                     >
//                       <Breadcrumb.Item>
//                         <Link to="/">Home</Link>
//                       </Breadcrumb.Item>
//                       <Breadcrumb.Item>
//                         <Link to="/bookings">Bookings</Link>
//                       </Breadcrumb.Item>
//                       <Breadcrumb.Item>
//                         <Link to={""}>
//                           {/* {converInUpperCase("Tourism")} */}
//                           Tourism
//                         </Link>
//                       </Breadcrumb.Item>
//                       <Breadcrumb.Item>
//                         {/* {converInUpperCase("Car")} */}
//                         Car
//                       </Breadcrumb.Item>
//                     </Breadcrumb>
//                   </Col>
//                   <Col md={8}>
//                     <div className="location-btn">
//                       {"Melbourne, 3000"}{" "}
//                       <Icon icon="location" size="15" className="ml-20" />
//                     </div>
//                   </Col>
//                 </Row>
//                 <Card
//                   title={
//                     <span className={"nostyle"}>
//                       {/* {converInUpperCase("Bali")} */}
//                       Bali
//                     </span>
//                   }
//                   bordered={false}
//                   extra={
//                     <ul className="panel-action">
//                       <li title={"List view"} className={"active"}>
//                         <Icon icon="grid" size="18" />
//                       </li>
//                       <li title={"Map view"}>
//                         <Icon icon="map" size="18" />
//                       </li>
//                       <li>
//                         <label>{"Sort"}&nbsp;&nbsp;</label>
//                         <Select
//                           defaultValue={"Recommended"}
//                           //onChange={this.handleSort}
//                           dropdownMatchSelectWidth={false}
//                         >
//                           <Option value="price_high">Price (High-Low)</Option>
//                           <Option value="price_low">Price (Low-High)</Option>
//                           <Option value="rating">Rating</Option>
//                           <Option value="most_viewed">Most Reviewed</Option>
//                           <Option value="name">Name List A-Z</Option>
//                           <Option value="distance">Distance</Option>
//                         </Select>
//                       </li>
//                     </ul>
//                   }
//                   className={"home-product-list header-nospace"}
//                 >
//                   <Row gutter={[60, 28]}>
//                     <Col className="gutter-row" md={7}>
//                       <div className="map-box">
//                         <img
//                           alt="Map"
//                           src={require("../../../../../assets/images/dummy-map.jpg")}
//                         />
//                       </div>
//                       <Title
//                         level={2}
//                         className="sub-heading pt-20 align-center"
//                       >
//                         {"Recommended for you in Bali"}
//                       </Title>

//                       {topRatedCarRentalData.map((item, index) => (
//                         <Row gutter={[28, 0]} className="pt-42" key={index}>
//                           <Col className="gutter-row" md={24}>
//                             <Card
//                               bordered={false}
//                               className={"tourism-toprated-car-card"}
//                               cover={<img alt={item.name} src={item.image} />}
//                             >
//                               <Row className={"mb-10"}>
//                                 <Col span={16}>
//                                   <div className="rate-section">
//                                     <Rate allowHalf defaultValue={3.0} />
//                                   </div>
//                                 </Col>
//                                 <Col span={8}>
//                                   <div className="europcar" align="right">
//                                     <img alt="" src={item.companyLogo} />
//                                   </div>
//                                 </Col>
//                               </Row>
//                               <div className="tag">{item.offer}</div>
//                               <div className="subcategory">
//                                 {item.subCategory}
//                               </div>
//                               <Title level={4} className="title">
//                                 {item.name}
//                               </Title>
//                               <Text className="sub-title">{item.similar}</Text>
//                               <div className="price-box">
//                                 <div className="price">
//                                   <Text className="from">From</Text>
//                                   <span>{item.price}</span>
//                                   <Text className="per-day">per day</Text>
//                                 </div>
//                               </div>
//                             </Card>
//                           </Col>
//                         </Row>
//                       ))}
//                     </Col>
//                     <Col className="gutter-row" md={17}>
//                       <div className="car-list-detail">
//                         <CarListDetail />
//                         <CarListDetail />
//                       </div>
//                     </Col>
//                   </Row>
//                 </Card>
//               </div>
//             </Content>
//           </Layout>
//         </Layout>
//         {redirectTo && (
//           <Redirect
//             push
//             to={{
//               pathname: redirectTo,
//             }}
//           />
//         )}
//       </Layout>
//     );
//   }
// }

// const mapStateToProps = (store) => {
//   const { auth, classifieds } = store;
//   return {
//     loggedInDetail: auth.loggedInUser,
//     isLoggedIn: auth.isLoggedIn,
//     selectedClassifiedList: classifieds.classifiedsList,
//   };
// };

// export default connect(mapStateToProps, {
//   mostPopularInHandyMan,
//   newInBookings,
//   mostPapularList,
//   getClassfiedCategoryListing,
//   enableLoading,
//   disableLoading,
//   classifiedGeneralSearch,
//   getClassfiedCategoryDetail,
//   getBannerById,
//   openLoginModel,
//   getChildCategory,
//   papularSearch,
//   getMostViewdData,
// })(withRouter(FlightList));
