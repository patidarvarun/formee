import React, { Fragment } from 'react';
import { Link } from 'react-router-dom'
import { Card, Row, Col, Rate, Typography } from 'antd';
import Icon from '../../../components/customIcons/customIcons';
import './tourismDetailCard.less';
const { Title, Text, Paragraph } = Typography;

const TourismDetailCard = ({
    imgSrc = '',
    title = '',
    titleSize,
    subTitle = '',
    titlePosition,
    onClick,
    priceLabel = '',
    price,
    pricePosition,
    textColor,
}) => {
    return (
        <Fragment>
            <Card
                bordered={false}
                className={'tourism-detail-card'}
                cover={
                    <img
                        //alt={tempData.discription}
                        src={require('../../../assets/images/most-booked-hotel.png')}
                    />
                }
                title={'Bangkok'}
            >
                <div className='tag'>Save 55%</div>
                <div className={'tourism-detail-card-top-section'}>
                    <div className='rate-section'>
                        <Rate allowHalf defaultValue={3.0} />
                    </div>
                    <div className={'right'}>
                        <span>
                            52 Views
                        </span>
                        <span>
                            <Icon icon='location' size='10' className={'mr-6'} />
                            Melbourne
                        </span>
                        <Icon icon='wishlist' size='20' />
                    </div>
                </div>
                <Row>
                    <Col span={24}>
                        <div className='category-box'>
                            <div className='category-name'>
                                {'Beauty'}
                            </div>
                        </div>
                        <div className='title' style={{
                            whiteSpace: 'nowrap',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis'
                        }}>
                            {'Remedial Brows'}
                        </div>
                        <div className='price-box'>
                            <div className='price'>
                                {'$1200'}
                                <sup className='sub-text'>per night</sup>
                            </div>
                        </div>
                    </Col>
                </Row>
            </Card>
            <div className={'tourism-detail-card-bottom-section'}>
                <div className='date-info'><strong>2 Hours</strong> Sun, 19 Jan - Tue, 14 Jan</div>
            </div>
        </Fragment>
    )
}

export default TourismDetailCard;