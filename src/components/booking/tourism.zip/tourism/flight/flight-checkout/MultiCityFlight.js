import React, { Fragment } from "react";
import { Link, Redirect, withRouter } from "react-router-dom";
// import { connect } from "react-redux";
// import AppSidebar from "../common/Sidebar";
import {
  Layout,
  Row,
  Col,
  Typography,
  Tabs,
  Card,
  Button,
  Breadcrumb,
} from "antd";
import {
  LeftOutlined,
  LockOutlined,
  CheckOutlined,
  ArrowRightOutlined,
} from "@ant-design/icons";

// import Icon from "../../../components/customIcons/customIcons";
// import { langs } from "../../../config/localization";
// import {
//   mostPopularInHandyMan,
//   newInBookings,
//   mostPapularList,
//   getMostViewdData,
//   getBannerById,
//   enableLoading,
//   disableLoading,
// } from "../../../../../actions/index";
// import {
//   papularSearch,
//   getClassfiedCategoryListing,
//   classifiedGeneralSearch,
//   getClassfiedCategoryDetail,
//   openLoginModel,
//   getChildCategory,
// } from "../../../../../actions";
// import history from "../../../../../common/History";
// import "../../../common/bannerCard/bannerCard.less";
// import { TEMPLATE } from "../../../../../config/Config";
// import NewSidebar from "../../../NewSidebar";
import "./booking-tourism-checkout.less";
import "./multi-city-flight.less";
const { Content } = Layout;
const { Title, Paragraph, Text } = Typography;

class MultiCityFlight extends React.Component {
  formRef = React.createRef();
  //   constructor() {
  //     super();
  //   }

  render() {
    return (
      <Layout className="common-sub-category-landing booking-sub-category-landing">
        <Layout className="yellow-theme common-left-right-padd">
          {/* <NewSidebar
            history={history}
            activeCategoryId={cat_id}
            categoryName={TEMPLATE.HANDYMAN}
            isSubcategoryPage={true}
            showAll={true}
            toggleSideBar={() =>
              this.setState({ isSidebarOpen: !isSidebarOpen })
            }
          /> */}
          <Layout className="right-parent-block booking-tourism-checkout-box">
            {/* <div className="inner-banner custom-inner-banner">
              <SubHeader categoryName={TEMPLATE.HANDYMAN} showAll={true} />
              <CarouselSlider bannerItem={topImages} pathName="/" />
            </div> */}
            <Content className="site-layout tourism-multi-city-flight-box">
              <div className="back-an-title-box">
                <LeftOutlined />
                <span className="title">Flights</span>
              </div>
              <div className="tourism-step-an-safeSecure-box">
                <div className="tourism-steps">
                  <div className="trsm-step active">
                    <div className="step">
                      <span className="step-digit">1</span>
                      <CheckOutlined />
                    </div>
                    <div className="step-name">Flight</div>
                    <img
                      src={require("../../../../../assets/images/icons/right-black-arrow.svg")}
                      alt="right-black-arrow"
                    />
                  </div>
                  <div className="trsm-step">
                    <div className="step">
                      <span className="step-digit">2</span>
                      <CheckOutlined />
                    </div>
                    <div className="step-name">Travellers</div>
                    <img
                      src={require("../../../../../assets/images/icons/right-black-arrow.svg")}
                      alt="right-black-arrow"
                    />
                  </div>
                  <div className="trsm-step">
                    <div className="step">
                      <span className="step-digit">3</span>
                      <CheckOutlined />
                    </div>
                    <div className="step-name">Pay</div>
                    <img
                      src={require("../../../../../assets/images/icons/right-black-arrow.svg")}
                      alt="right-black-arrow"
                    />
                  </div>
                </div>
                <div className="safe-secure-btn-box">
                  <Button>
                    <img
                      src={require("../../../../../assets/images/icons/lock-dark-grey.svg")}
                      alt="lock-dark-grey"
                    />
                    <span>Safe and secure checkout</span>
                  </Button>
                </div>
              </div>
            </Content>
          </Layout>
        </Layout>
        {/* {redirectTo && (
          <Redirect
            push
            to={{
              pathname: redirectTo,
            }}
          />
        )} */}
      </Layout>
    );
  }
}

export default MultiCityFlight;
